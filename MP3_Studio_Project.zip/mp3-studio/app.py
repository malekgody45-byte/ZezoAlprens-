from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import threading
import time
import uuid
import zipfile
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

from fastapi import BackgroundTasks, FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field, field_validator

BASE_DIR = Path(__file__).resolve().parent
STATIC_DIR = BASE_DIR / "static"
DATA_DIR = Path(os.getenv("MP3_STUDIO_DATA", "/tmp/mp3-studio-data"))
DATA_DIR.mkdir(parents=True, exist_ok=True)

app = FastAPI(title="MP3 Studio", version="1.0.0")
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")

JOBS: dict[str, dict[str, Any]] = {}
JOBS_LOCK = threading.RLock()
ACTIVE_LOCK = threading.Lock()
MAX_LINKS = 20
MAX_JOB_AGE_SECONDS = 2 * 60 * 60

ALLOWED_DOMAINS = {
    "youtube.com", "www.youtube.com", "m.youtube.com", "music.youtube.com",
    "youtu.be", "youtube-nocookie.com", "www.youtube-nocookie.com",
    "tiktok.com", "www.tiktok.com", "m.tiktok.com", "vm.tiktok.com", "vt.tiktok.com",
    "facebook.com", "www.facebook.com", "m.facebook.com", "fb.watch", "web.facebook.com",
}


class ProcessRequest(BaseModel):
    urls: list[str] = Field(min_length=1, max_length=MAX_LINKS)
    mode: str = Field(default="separate", pattern="^(separate|combined)$")
    bitrate: int = Field(default=192)
    normalize: bool = True

    @field_validator("urls")
    @classmethod
    def validate_urls(cls, urls: list[str]) -> list[str]:
        cleaned: list[str] = []
        seen: set[str] = set()
        for raw in urls:
            url = raw.strip()
            if not url:
                continue
            if len(url) > 2048:
                raise ValueError("أحد الروابط أطول من الحد المسموح.")
            parsed = urlparse(url)
            host = (parsed.hostname or "").lower().rstrip(".")
            # Exact host allow-list; do not allow arbitrary URLs or local-network targets.
            if parsed.scheme not in {"http", "https"} or host not in ALLOWED_DOMAINS:
                raise ValueError("استخدم روابط عامة من YouTube أو TikTok أو Facebook فقط.")
            if url not in seen:
                cleaned.append(url)
                seen.add(url)
        if not cleaned:
            raise ValueError("أضف رابطًا واحدًا صحيحًا على الأقل.")
        if len(cleaned) > MAX_LINKS:
            raise ValueError(f"الحد الأقصى هو {MAX_LINKS} رابطًا في الدفعة الواحدة.")
        return cleaned

    @field_validator("bitrate")
    @classmethod
    def validate_bitrate(cls, value: int) -> int:
        if value not in {128, 192, 256, 320}:
            raise ValueError("اختر جودة 128 أو 192 أو 256 أو 320 kbps.")
        return value


def clean_label(value: str, limit: int = 100) -> str:
    value = re.sub(r"[\x00-\x1f<>:\"/\\|?*]+", " ", value or "")
    value = re.sub(r"\s+", " ", value).strip(" .-")
    return (value or "audio")[:limit]


def job_update(job_id: str, **fields: Any) -> None:
    with JOBS_LOCK:
        if job_id in JOBS:
            JOBS[job_id].update(fields)
            JOBS[job_id]["updated_at"] = time.time()


def cleanup_old_jobs() -> None:
    now = time.time()
    with JOBS_LOCK:
        stale = [jid for jid, job in JOBS.items()
                 if now - job.get("created_at", now) > MAX_JOB_AGE_SECONDS
                 and job.get("status") not in {"queued", "processing"}]
        for jid in stale:
            shutil.rmtree(DATA_DIR / jid, ignore_errors=True)
            JOBS.pop(jid, None)


def run_ffmpeg(input_path: Path, output_path: Path, bitrate: int, normalize: bool) -> None:
    command = ["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-i", str(input_path), "-vn"]
    if normalize:
        command += ["-af", "loudnorm=I=-16:TP=-1.5:LRA=11"]
    command += ["-codec:a", "libmp3lame", "-b:a", f"{bitrate}k", "-map_metadata", "0", "-id3v2_version", "3", str(output_path)]
    result = subprocess.run(command, capture_output=True, text=True, timeout=60 * 60)
    if result.returncode != 0 or not output_path.exists() or output_path.stat().st_size == 0:
        detail = (result.stderr or "تعذر تحويل الصوت إلى MP3.").strip()[-500:]
        raise RuntimeError(detail)


def find_downloaded_file(folder: Path, video_id: str, prepared_name: str | None) -> Path:
    if prepared_name:
        prepared = Path(prepared_name)
        if prepared.exists():
            return prepared
    candidates = [p for p in folder.glob(f"{video_id}.*") if p.is_file() and p.suffix.lower() not in {".part", ".ytdl", ".json", ".jpg", ".webp", ".png"}]
    if not candidates:
        candidates = [p for p in folder.iterdir() if p.is_file() and p.suffix.lower() not in {".part", ".ytdl", ".json", ".jpg", ".webp", ".png", ".mp3"}]
    if not candidates:
        raise RuntimeError("لم أتمكن من العثور على ملف الصوت الناتج من الرابط.")
    return max(candidates, key=lambda p: p.stat().st_mtime)


def process_job(job_id: str, payload: dict[str, Any]) -> None:
    # Keep only one heavy batch at a time on small/free hosting instances.
    if not ACTIVE_LOCK.acquire(blocking=False):
        job_update(job_id, status="failed", message="الخادم مشغول حاليًا. أعد المحاولة بعد قليل.")
        return

    from yt_dlp import YoutubeDL

    job_root = DATA_DIR / job_id
    source_dir = job_root / "source"
    output_dir = job_root / "output"
    source_dir.mkdir(parents=True, exist_ok=True)
    output_dir.mkdir(parents=True, exist_ok=True)
    urls: list[str] = payload["urls"]
    total = len(urls)
    bitrate = int(payload["bitrate"])
    normalize = bool(payload["normalize"])
    output_items: list[dict[str, Any]] = []
    errors: list[str] = []

    try:
        job_update(job_id, status="processing", progress=2, message="جارٍ تجهيز المهمة…", current=0)
        for index, url in enumerate(urls, start=1):
            current_title = f"الرابط {index} من {total}"
            job_update(job_id, current=index, progress=int(4 + (index - 1) / total * 78), message=f"جارٍ استخراج الصوت: {current_title}", current_title=current_title)
            hook_last_update = [0.0]

            def progress_hook(info: dict[str, Any]) -> None:
                now = time.time()
                if info.get("status") == "downloading" and now - hook_last_update[0] >= 0.4:
                    hook_last_update[0] = now
                    downloaded = info.get("downloaded_bytes") or 0
                    total_bytes = info.get("total_bytes") or info.get("total_bytes_estimate") or 0
                    if total_bytes:
                        local_progress = 100.0 * downloaded / total_bytes
                    else:
                        percent_raw = re.sub(r"\x1b\[[0-9;]*m", "", str(info.get("_percent_str", ""))).replace("%", "").strip()
                        try:
                            local_progress = float(percent_raw)
                        except (TypeError, ValueError):
                            local_progress = 0.0
                    overall = min(82, int(4 + ((index - 1) + max(0, min(local_progress, 100)) / 100) / total * 78))
                    job_update(job_id, progress=overall, message=f"جارٍ تحميل الصوت ({index}/{total}) — {int(local_progress)}%")
                elif info.get("status") == "finished":
                    overall = min(84, int(4 + index / total * 78))
                    job_update(job_id, progress=overall, message=f"تم جلب المصدر، جارٍ تحويله إلى MP3 ({index}/{total})…")

            options = {
                "format": "bestaudio/best",
                "outtmpl": str(source_dir / f"source_{index:02d}_%(id)s.%(ext)s"),
                "noplaylist": True,
                "quiet": True,
                "no_warnings": True,
                "ignoreerrors": False,
                "retries": 2,
                "fragment_retries": 2,
                "socket_timeout": 25,
                "progress_hooks": [progress_hook],
                "restrictfilenames": True,
                "cachedir": False,
            }
            try:
                with YoutubeDL(options) as ydl:
                    info = ydl.extract_info(url, download=True)
                    if not info:
                        raise RuntimeError("تعذر جلب معلومات الرابط.")
                    title = clean_label(info.get("title") or f"audio_{index}")
                    video_id = str(info.get("id") or "")
                    try:
                        prepared = ydl.prepare_filename(info)
                    except Exception:
                        prepared = None
                source_file = find_downloaded_file(source_dir, video_id, prepared)
                final_name = f"{index:02d}_{clean_label(title, 80)}.mp3"
                final_path = output_dir / final_name
                run_ffmpeg(source_file, final_path, bitrate, normalize)
                output_items.append({
                    "name": final_name,
                    "title": title,
                    "size": final_path.stat().st_size,
                    "path": str(final_path),
                    "source_index": index,
                })
            except Exception as exc:
                safe_error = str(exc).replace("\n", " ")[:180]
                errors.append(f"الرابط {index}: {safe_error}")
            job_update(job_id, progress=min(88, int(8 + index / total * 78)), message=f"اكتمل تجهيز الرابط {index} من {total}.")

        if not output_items:
            raise RuntimeError("لم ينجح تحويل أي رابط. تحقق من أن الروابط عامة ومتاحة ثم أعد المحاولة.")

        if payload["mode"] == "combined" and len(output_items) > 1:
            job_update(job_id, progress=91, message="جارٍ دمج ملفات الصوت في ملف MP3 واحد…")
            combined_path = output_dir / "MP3_Studio_Combined.mp3"
            manifest = job_root / "concat.txt"
            # FFmpeg concat demuxer requires single-quoted escaped paths.
            rows = []
            for item in output_items:
                escaped = item["path"].replace("'", "'\\''")
                rows.append(f"file '{escaped}'")
            manifest.write_text("\n".join(rows), encoding="utf-8")
            result = subprocess.run(
                ["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-f", "concat", "-safe", "0", "-i", str(manifest), "-c", "copy", str(combined_path)],
                capture_output=True, text=True, timeout=60 * 60,
            )
            if result.returncode != 0 or not combined_path.exists() or combined_path.stat().st_size == 0:
                # Re-encode each input through the concat filter as a robust fallback.
                command = ["ffmpeg", "-hide_banner", "-loglevel", "error", "-y"]
                for item in output_items:
                    command += ["-i", item["path"]]
                concat_inputs = "".join(f"[{i}:a]" for i in range(len(output_items)))
                filter_value = f"{concat_inputs}concat=n={len(output_items)}:v=0:a=1[outa]"
                command += ["-filter_complex", filter_value, "-map", "[outa]", "-codec:a", "libmp3lame", "-b:a", f"{bitrate}k", str(combined_path)]
                fallback = subprocess.run(command, capture_output=True, text=True, timeout=60 * 60)
                if fallback.returncode != 0 or not combined_path.exists() or combined_path.stat().st_size == 0:
                    raise RuntimeError("تعذر دمج الملفات. جرّب وضع الملفات المنفصلة أو قلّل عدد الروابط.")
            output_items = [{
                "name": combined_path.name,
                "title": "ملف MP3 الموحّد",
                "size": combined_path.stat().st_size,
                "path": str(combined_path),
                "source_index": 0,
            }]

        # A convenience ZIP is created for separate-file mode, while retaining each MP3 for preview.
        zip_path = None
        if payload["mode"] == "separate" and len(output_items) > 1:
            zip_path = output_dir / "MP3_Studio_All_Files.zip"
            with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
                for item in output_items:
                    archive.write(item["path"], arcname=item["name"])
        # Keep output paths internal; APIs expose only generated file names.
        job_update(job_id, status="completed", progress=100, message="اكتملت المعالجة. شغّل المعاينة ثم نزّل الملف.", outputs=output_items, zip_path=str(zip_path) if zip_path else None, errors=errors, completed_at=time.time())
    except Exception as exc:
        job_update(job_id, status="failed", progress=100, message=str(exc)[:350], errors=errors)
    finally:
        # Remove bulky source files as soon as final MP3s are ready.
        shutil.rmtree(source_dir, ignore_errors=True)
        ACTIVE_LOCK.release()


def public_job(job_id: str, job: dict[str, Any]) -> dict[str, Any]:
    outputs = []
    for item in job.get("outputs", []):
        name = item["name"]
        outputs.append({
            "name": name,
            "title": item["title"],
            "size": item["size"],
            "preview_url": f"/api/files/{job_id}/{name}",
            "download_url": f"/api/files/{job_id}/{name}?download=1",
        })
    return {
        "id": job_id,
        "status": job.get("status", "queued"),
        "progress": job.get("progress", 0),
        "message": job.get("message", "جارٍ الانتظار…"),
        "current": job.get("current", 0),
        "current_title": job.get("current_title", ""),
        "total": job.get("total", 0),
        "mode": job.get("mode", "separate"),
        "outputs": outputs,
        "errors": job.get("errors", []),
    }


@app.get("/", response_class=HTMLResponse)
def home() -> str:
    return (STATIC_DIR / "index.html").read_text(encoding="utf-8")


@app.get("/api/health")
def health() -> dict[str, str]:
    return {"status": "ok", "app": "MP3 Studio"}


@app.post("/api/process", status_code=202)
def start_process(request: ProcessRequest, background_tasks: BackgroundTasks, client_request: Request) -> dict[str, Any]:
    cleanup_old_jobs()
    job_id = uuid.uuid4().hex[:16]
    job_root = DATA_DIR / job_id
    job_root.mkdir(parents=True, exist_ok=True)
    now = time.time()
    with JOBS_LOCK:
        JOBS[job_id] = {
            "id": job_id,
            "status": "queued",
            "progress": 0,
            "message": "تمت إضافة المهمة إلى قائمة المعالجة.",
            "created_at": now,
            "updated_at": now,
            "total": len(request.urls),
            "outputs": [],
            "errors": [],
            "mode": request.mode,
        }
    background_tasks.add_task(process_job, job_id, request.model_dump())
    return {"id": job_id, "status": "queued", "message": "تم استقبال الروابط."}


@app.get("/api/jobs/{job_id}")
def get_job(job_id: str) -> dict[str, Any]:
    with JOBS_LOCK:
        job = JOBS.get(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="المهمة غير موجودة أو انتهت مدة الاحتفاظ بها.")
    return public_job(job_id, job)


@app.get("/api/files/{job_id}/{filename}")
def get_file(job_id: str, filename: str, download: int = 0):
    with JOBS_LOCK:
        job = JOBS.get(job_id)
    if not job or job.get("status") != "completed":
        raise HTTPException(status_code=404, detail="الملف غير جاهز أو انتهت صلاحيته.")
    item = next((x for x in job.get("outputs", []) if x.get("name") == filename), None)
    if not item:
        raise HTTPException(status_code=404, detail="الملف غير موجود.")
    path = Path(item["path"])
    if not path.is_file():
        raise HTTPException(status_code=404, detail="انتهت مدة الاحتفاظ بالملف. أنشئه مجددًا.")
    return FileResponse(path, media_type="audio/mpeg", filename=filename if download else None, content_disposition_type="attachment" if download else "inline")


@app.exception_handler(ValueError)
async def value_error_handler(request: Request, exc: ValueError):
    return JSONResponse(status_code=400, content={"detail": str(exc)})


@app.get("/api/bundle/{job_id}")
def get_bundle(job_id: str):
    with JOBS_LOCK:
        job = JOBS.get(job_id)
    if not job or job.get("status") != "completed" or not job.get("zip_path"):
        raise HTTPException(status_code=404, detail="ملف التجميع غير متاح لهذه المهمة.")
    path = Path(job["zip_path"])
    if not path.is_file():
        raise HTTPException(status_code=404, detail="انتهت مدة الاحتفاظ بالملفات. أنشئها مجددًا.")
    return FileResponse(path, media_type="application/zip", filename="MP3_Studio_All_Files.zip")
