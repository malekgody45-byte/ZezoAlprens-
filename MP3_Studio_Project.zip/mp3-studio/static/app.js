(() => {
  const $ = (selector) => document.querySelector(selector);
  const urlsInput = $('#urls');
  const urlCount = $('#urlCount');
  const startBtn = $('#startBtn');
  const resultsPanel = $('#resultsPanel');
  const resultsContent = $('#resultsContent');
  const resultsTitle = $('#resultsTitle');
  const statusPill = $('#statusPill');
  const progressMessage = $('#progressMessage');
  const progressPercent = $('#progressPercent');
  const progressFill = $('#progressFill');
  const errorList = $('#errorList');
  const resultActions = $('#resultActions');
  const bitrate = $('#bitrate');
  let lastJobId = null;
  let lastUrls = [];
  let pollTimer = null;
  let isBusy = false;

  function extractUrls() {
    const raw = urlsInput.value.split(/[\n\r,]+/).map(s => s.trim()).filter(Boolean);
    return [...new Set(raw)];
  }

  function updateCount() {
    const count = extractUrls().length;
    urlCount.textContent = `${count} / 20 روابط`;
    urlCount.classList.toggle('over-limit', count > 20);
    if (count > 20) urlCount.textContent = `${count} / 20 — قلّل عدد الروابط`;
  }
  urlsInput.addEventListener('input', updateCount);
  $('#clearLinks').addEventListener('click', () => { urlsInput.value = ''; updateCount(); urlsInput.focus(); });

  document.querySelectorAll('input[name="mode"]').forEach(radio => {
    radio.addEventListener('change', () => {
      $('#separateOption').classList.toggle('selected', radio.value === 'separate' && radio.checked);
      $('#combinedOption').classList.toggle('selected', radio.value === 'combined' && radio.checked);
    });
  });

  const qualityText = {
    '128': ['حجم أصغر مناسب للاستماع العادي', 1],
    '192': ['توازن جيد بين الجودة والحجم', 2],
    '256': ['جودة مرتفعة مع حجم متوسط', 3],
    '320': ['أعلى معدل بت متاح في الأداة', 4],
  };
  bitrate.addEventListener('change', () => {
    const entry = qualityText[bitrate.value] || qualityText['192'];
    $('#qualityNote').textContent = entry[0];
    $('.quality-meter').dataset.level = entry[1];
  });
  bitrate.dispatchEvent(new Event('change'));

  function setBusy(busy) {
    isBusy = busy;
    startBtn.disabled = busy;
    startBtn.querySelector('span:nth-child(2)').textContent = busy ? 'جارٍ تجهيز الصوت…' : 'ابدأ تحويل الصوت';
    startBtn.querySelector('.btn-icon').innerHTML = busy
      ? '<span class="spinner" aria-hidden="true"></span>'
      : '<svg viewBox="0 0 24 24"><path d="M12 3v12m0 0 5-5m-5 5-5-5M5 16v3a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-3"/></svg>';
  }

  function showError(message) {
    resultsPanel.classList.remove('hidden');
    resultsTitle.textContent = 'لم تبدأ المعالجة';
    statusPill.textContent = 'تحقق من المدخلات';
    progressMessage.textContent = message;
    progressPercent.textContent = '—';
    progressFill.style.width = '0%';
    resultsContent.innerHTML = '';
    errorList.classList.add('hidden');
    resultActions.classList.remove('hidden');
    $('#retryBtn').classList.toggle('hidden', !lastUrls.length);
  }

  async function startJob(urls = extractUrls()) {
    if (isBusy) return;
    if (!urls.length) { showError('أضف رابطًا واحدًا على الأقل قبل بدء المعالجة.'); return; }
    if (urls.length > 20) { showError('الحد الأقصى هو 20 رابطًا في الدفعة الواحدة.'); return; }
    if (!$('#rightsConfirm').checked) { showError('يرجى تأكيد أن لديك الحق أو الإذن اللازم لمعالجة هذه الروابط.'); return; }

    if (pollTimer) clearTimeout(pollTimer);
    lastUrls = [...urls];
    resultsPanel.classList.remove('hidden');
    resultsPanel.scrollIntoView({ behavior: 'smooth', block: 'start' });
    resultsTitle.textContent = 'جاري تجهيز الصوت';
    statusPill.textContent = 'قيد المعالجة';
    progressMessage.textContent = 'جارٍ إرسال الروابط إلى المعالج…';
    progressPercent.textContent = '0%';
    progressFill.style.width = '0%';
    resultsContent.innerHTML = '';
    errorList.classList.add('hidden');
    resultActions.classList.add('hidden');
    setBusy(true);

    const payload = {
      urls,
      mode: document.querySelector('input[name="mode"]:checked').value,
      bitrate: Number(bitrate.value),
      normalize: $('#normalize').checked,
    };
    try {
      const response = await fetch('/api/process', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(data.detail || 'تعذر إرسال المهمة إلى الخادم.');
      lastJobId = data.id;
      await pollJob();
    } catch (err) {
      setBusy(false);
      showError(err.message || 'حدث اتصال غير متوقع. تحقق من اتصال الإنترنت ثم أعد المحاولة.');
    }
  }

  async function pollJob() {
    if (!lastJobId) return;
    try {
      const response = await fetch(`/api/jobs/${encodeURIComponent(lastJobId)}`, { cache: 'no-store' });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(data.detail || 'تعذر قراءة حالة المهمة.');
      renderJob(data);
      if (data.status === 'queued' || data.status === 'processing') {
        pollTimer = setTimeout(pollJob, 1100);
      } else {
        setBusy(false);
      }
    } catch (err) {
      setBusy(false);
      statusPill.textContent = 'تعذّر الاتصال';
      progressMessage.textContent = err.message || 'تعذر تحديث حالة المهمة.';
      resultActions.classList.remove('hidden');
      $('#retryBtn').classList.remove('hidden');
    }
  }

  function formatSize(bytes) {
    if (!Number.isFinite(bytes) || bytes <= 0) return 'حجم غير معروف';
    const mb = bytes / (1024 * 1024);
    return mb >= 1 ? `${mb.toFixed(2)} MB` : `${Math.max(1, Math.round(bytes / 1024))} KB`;
  }

  function escapeHtml(value) {
    return String(value).replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
  }

  function renderJob(job) {
    const progress = Math.max(0, Math.min(100, Number(job.progress) || 0));
    progressFill.style.width = `${progress}%`;
    progressPercent.textContent = `${progress}%`;
    progressMessage.textContent = job.message || 'جارٍ المعالجة…';
    statusPill.textContent = job.status === 'completed' ? 'اكتمل بنجاح' : job.status === 'failed' ? 'توقفت المعالجة' : 'قيد المعالجة';
    resultsTitle.textContent = job.status === 'completed' ? 'الصوت جاهز للمعاينة' : job.status === 'failed' ? 'تعذر إكمال المعالجة' : 'جاري تجهيز الصوت';

    if (job.status === 'completed') {
      resultsContent.innerHTML = (job.outputs || []).map((output, index) => `
        <article class="result-file">
          <div class="file-icon">MP3</div>
          <div class="file-body">
            <div class="file-title-row"><span class="file-title">${escapeHtml(output.title || output.name)}</span><span class="file-size">${formatSize(output.size)}</span></div>
            <audio class="audio-player" controls preload="metadata" src="${escapeHtml(output.preview_url)}">متصفحك لا يدعم مشغل الصوت.</audio>
            <div class="file-actions"><a class="download-link" href="${escapeHtml(output.download_url)}" download><span>↓</span> تنزيل MP3</a><span class="preview-label">استمع قبل التنزيل</span></div>
          </div>
        </article>`).join('');
      if (job.outputs && job.outputs.length > 1 && job.mode !== 'combined') {
        resultsContent.insertAdjacentHTML('beforeend', `<a class="download-link zip-download" href="/api/bundle/${encodeURIComponent(job.id)}"><span>↓</span> تنزيل كل الملفات في ZIP</a>`);
      }
      resultActions.classList.remove('hidden');
      $('#retryBtn').classList.add('hidden');
      $('#newBatchBtn').classList.remove('hidden');
      errorList.classList.toggle('hidden', !(job.errors && job.errors.length));
      if (job.errors && job.errors.length) errorList.textContent = `بعض الروابط لم تكتمل: ${job.errors.join(' | ')}`;
    } else if (job.status === 'failed') {
      resultsContent.innerHTML = '';
      resultActions.classList.remove('hidden');
      $('#retryBtn').classList.remove('hidden');
      $('#newBatchBtn').classList.remove('hidden');
      if (job.errors && job.errors.length) {
        errorList.classList.remove('hidden');
        errorList.textContent = job.errors.join(' | ');
      } else {
        errorList.classList.add('hidden');
      }
    }
  }

  startBtn.addEventListener('click', () => startJob());
  $('#retryBtn').addEventListener('click', () => startJob(lastUrls));
  $('#newBatchBtn').addEventListener('click', () => {
    if (pollTimer) clearTimeout(pollTimer);
    lastJobId = null;
    lastUrls = [];
    resultsPanel.classList.add('hidden');
    resultsContent.innerHTML = '';
    setBusy(false);
    urlsInput.focus();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });

  const style = document.createElement('style');
  style.textContent = '.spinner{display:block;width:14px;height:14px;border:2px solid rgba(9,50,55,.25);border-top-color:#164248;border-radius:50%;animation:mp3spin .7s linear infinite}@keyframes mp3spin{to{transform:rotate(360deg)}}';
  document.head.appendChild(style);
  updateCount();
})();
